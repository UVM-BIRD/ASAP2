# Supplemental Data
## Exploring Complex Disease Gene Relationships Using Simultaneous Analysis

- - -

### Contents of `supplemental_data` directory:

This compressed archive contains two sets of data files: protein data files, and nucleotide data files.

There are two top-level directories:

*   `nucleotide` - contains nucleotide data files
*   `protein` - likewise, contains protein data files

Within each of those directories are the following contents:

*   A JSON data structure listing GenBank/GenPept GIs or Accession Numbers for the sequences identified by ASAP2
*   An `aligned_sequences` directory, containing FASTA files with the sequences for each data partition
*   A `tnt_input_files` directory, containing the aforementioned aligned data partitions formatted to be used as TNT input